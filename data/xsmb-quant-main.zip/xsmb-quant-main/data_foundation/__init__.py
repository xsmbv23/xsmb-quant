"""XSMB forensic data foundation."""
