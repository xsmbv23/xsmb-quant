"""Immutable evidence persistence boundary."""
